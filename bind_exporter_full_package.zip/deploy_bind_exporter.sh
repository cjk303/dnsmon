#!/usr/bin/env bash
set -e

EXPORTER_DIR="/opt/bind_exporter"
SERVICE_FILE="/etc/systemd/system/bind_exporter.service"
PYTHON_BIN="/usr/bin/python3"
EXPORTER_SCRIPT="bind_exporter.py"
EXPORTER_PORT="9119"
RUN_USER="bind"
RUN_GROUP="bind"

echo "[*] Creating exporter directory..."
sudo mkdir -p "$EXPORTER_DIR"
sudo cp "$EXPORTER_SCRIPT" "$EXPORTER_DIR/"
sudo chown -R $RUN_USER:$RUN_GROUP "$EXPORTER_DIR"

echo "[*] Installing Python dependencies..."
sudo $PYTHON_BIN -m pip install --upgrade pip
sudo $PYTHON_BIN -m pip install prometheus_client dnspython

echo "[*] Creating systemd unit file..."
sudo tee "$SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=BIND Prometheus Exporter
After=network.target

[Service]
Type=simple
ExecStart=$PYTHON_BIN $EXPORTER_DIR/$EXPORTER_SCRIPT
Restart=always
RestartSec=5
User=$RUN_USER
Group=$RUN_GROUP
WorkingDirectory=$EXPORTER_DIR
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

echo "[*] Reloading systemd and enabling service..."
sudo systemctl daemon-reload
sudo systemctl enable --now bind_exporter.service

echo "[*] Deployment complete!"
echo "    Exporter should now be running on http://localhost:$EXPORTER_PORT/metrics"
echo "    Check status: sudo systemctl status bind_exporter.service"
