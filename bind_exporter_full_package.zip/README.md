# BIND Prometheus Exporter & Grafana Dashboard (Full Deployment Package)

This package contains:
- Python exporter script (`bind_exporter.py`)
- Grafana dashboard with alerts (`bind_dashboard.json`)
- Systemd service file (`bind_exporter.service`)
- Deployment script (`deploy_bind_exporter.sh`)
- README (this file)

## Deployment Steps

1. **Upload package** to your BIND server
2. **Extract package**:
   ```bash
   unzip bind_exporter_full_package.zip
   cd bind_exporter_full_package
   ```
3. **Run deployment**:
   ```bash
   chmod +x deploy_bind_exporter.sh
   ./deploy_bind_exporter.sh
   ```
4. **Import Grafana Dashboard**:
   - Go to **Dashboards → Import**
   - Upload `bind_dashboard.json`
   - Select Prometheus as the data source

5. **Verify Exporter**:
   ```bash
   curl http://localhost:9119/metrics
   ```

